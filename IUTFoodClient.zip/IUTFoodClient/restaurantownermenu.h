#ifndef RESTAURANTOWNERMENU_H
#define RESTAURANTOWNERMENU_H

#include <QWidget>
#include <QScrollArea>
#include <QVBoxLayout>
#include "restaurantitem.h"
#include "fooditemwidget.h"
#include <QInputDialog>

namespace Ui {
class restaurantownermenu;
}

class restaurantownermenu : public QWidget
{
    Q_OBJECT

public:
    explicit restaurantownermenu(QWidget *parent = nullptr);
    ~restaurantownermenu();

private slots:
    void on_addFoodButton_clicked();

    void on_viewOrdersButton_clicked();

    void on_ChangeOfStatusButton_clicked();

    void on_menuManagementButton_2_clicked();

    void on_ChangeOfStatusButton_2_clicked();

    void on_menuManagementButton_5_clicked();

    void on_viewOrdersButton_5_clicked();

private:
    Ui::restaurantownermenu *ui;

    QList<MenuItem> foodList;
    QScrollArea* scrollArea;
    QWidget* container;
    QVBoxLayout* layout;

    void renderMenuItems();
    void addFoodItem(const MenuItem& item);

};

#endif // RESTAURANTOWNERMENU_H
