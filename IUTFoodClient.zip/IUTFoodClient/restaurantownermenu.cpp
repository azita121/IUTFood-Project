#include "restaurantownermenu.h"
#include "ui_restaurantownermenu.h"

restaurantownermenu::restaurantownermenu(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::restaurantownermenu)
{
    ui->setupUi(this);

    scrollArea = new QScrollArea(this);
    scrollArea->setWidgetResizable(true);
    scrollArea->setVerticalScrollBarPolicy(Qt::ScrollBarAsNeeded);
    scrollArea->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);

    scrollArea->setStyleSheet(R"(
    QScrollArea, QScrollArea > QWidget > QWidget {
        background-color: #fdfdfd;
    }
    QScrollBar:vertical {
        width: 6px;
        background: #eee;
    }
    QScrollBar::handle:vertical {
        background: #999;
        border-radius: 3px;
    }
)");

    container = new QWidget(this);
    layout = new QVBoxLayout(container);
    container->setLayout(layout);
    scrollArea->setWidget(container);

    QVBoxLayout* mainLayout = qobject_cast<QVBoxLayout*>(ui->menuHolder->layout());
    if (!mainLayout) {
        mainLayout = new QVBoxLayout(ui->menuHolder);
        ui->menuHolder->setLayout(mainLayout);
    }
    mainLayout->addWidget(scrollArea);

    connect(ui->addFoodButton, &QPushButton::clicked, this, &restaurantownermenu::on_addFoodButton_clicked);

    // افزودن غذاهای تستی برای نمایش اولیه
    MenuItem f1 = { "Kebab", 120000, "Delicious Persian kebab" };
    MenuItem f2 = { "Pizza", 180000, "Cheesy Italian pizza" };
    MenuItem f3 = { "Salad", 60000, "Fresh garden salad" };
    MenuItem f4 = { "Kebab", 120000, "Delicious Persian kebab" };


    foodList.append(f1);
    foodList.append(f2);
    foodList.append(f3);
    foodList.append(f4);

    // رندر کردن منو پس از افزودن آیتم‌ها
    renderMenuItems();

}

restaurantownermenu::~restaurantownermenu()
{
    delete ui;
}

void restaurantownermenu::on_addFoodButton_clicked()
{
    QString name = QInputDialog::getText(this, "Add Food", "Food name:");
    if (name.isEmpty()) return;

    int price = QInputDialog::getInt(this, "Add Food", "Price:");
    QString desc = QInputDialog::getText(this, "Add Food", "Description:");

    MenuItem newItem = { name, price, desc };
    foodList.append(newItem);
    renderMenuItems();
}

void restaurantownermenu::renderMenuItems()
{
    QLayoutItem* item;
    while ((item = layout->takeAt(0)) != nullptr) {
        if (item->widget()) item->widget()->deleteLater();
        delete item;
    }

    for (const MenuItem& m : foodList) {
        FoodItemWidget* foodWidget = new FoodItemWidget(m, this);
        foodWidget->setFoodData(m);

        foodWidget->setShowAddButton(false);

        connect(foodWidget, &FoodItemWidget::foodRemoved, this, [=](const MenuItem& removedItem) {
            foodList.removeOne(removedItem);
            renderMenuItems();
        });

        layout->addWidget(foodWidget);
    }

}

void restaurantownermenu::on_viewOrdersButton_clicked()
{
    ui->stackedWidget->setCurrentIndex(1);
}


void restaurantownermenu::on_ChangeOfStatusButton_clicked()
{
    ui->stackedWidget->setCurrentIndex(2);
}


void restaurantownermenu::on_menuManagementButton_2_clicked()
{
    ui->stackedWidget->setCurrentIndex(0);
}


void restaurantownermenu::on_ChangeOfStatusButton_2_clicked()
{
    ui->stackedWidget->setCurrentIndex(2);
}


void restaurantownermenu::on_menuManagementButton_5_clicked()
{
    ui->stackedWidget->setCurrentIndex(0);
}


void restaurantownermenu::on_viewOrdersButton_5_clicked()
{
    ui->stackedWidget->setCurrentIndex(1);
}

